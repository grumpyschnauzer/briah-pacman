# Briah Pac-Man — Browser-ready Pygbag version

This folder is prepared for **pygbag**, so the game can run in a web browser.

## Test desktop version

```bash
pip install pygame
python main.py
```

## Build browser version locally

```bash
pip install pygbag
pygbag .
```

When the build finishes, pygbag creates a folder similar to:

```text
build/web/
```

Open the local web server URL that pygbag prints in the terminal.

## Put it on GitHub Pages

1. Create a GitHub repo, for example `briah-pacman`.
2. Upload these files/folders:
   - `main.py`
   - `requirements.txt`
   - `assets/`
3. On your computer, run:

```bash
pip install pygbag
pygbag .
```

4. Upload the contents of `build/web/` to GitHub.
5. In GitHub, go to **Settings → Pages**.
6. Choose **Deploy from branch** and select the branch/folder that contains the web files.

Your friends will use a link like:

```text
https://YOUR_USERNAME.github.io/briah-pacman/
```

## Controls

- Arrow keys / WASD: move
- P: pause
- R: restart after win/lose
- Enter / Space: start


## Browser build note

Pygbag may warn that WAV files are not its preferred browser audio format.
This package's Windows build file now uses:

```bash
python -m pygbag --disable-sound-format-error .
```

That allows the build to finish. If audio is inconsistent in the browser,
the game should still play normally.
