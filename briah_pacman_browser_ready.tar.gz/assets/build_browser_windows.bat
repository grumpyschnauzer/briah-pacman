@echo off
echo Installing pygbag...
python -m pip install pygbag

echo Building browser version...
python -m pygbag --disable-sound-format-error .

echo.
echo Done.
echo.
echo If the browser did not open automatically, open this folder:
echo build\web
echo.
pause
